1.安全启动文档详细设计方案请参考 [MT8676]-[secure boot] 软件详细设计说明书[V0.7].doc，8668 的也参考此文档。
  
2. 8676和8668 差别会在文档注明，每一步都需要谨慎，后续如果疏忽导致机器刷完起不来，查起来很麻烦；
   ①注意1：python 版本，76默认用python系统就行，68如果报错使用 prebuilts/build-tools/path/linux-x86/python
   ②注意2：在生成 android和yocto cert1和cert2密钥时使用的型号文档默认是76，68 是mt6881 	
   ③注意3：因为efuse只能写一次，所以开发阶段不建议写efuse栏位，除非你们需要真的测试efuse 的功能，拿一两天设备进行测试，配置可以按照文档efuse部分
   
3.安全启动版本编译完之后是和普通版本一样 默认把android侧的指定IMG 合并到 yocto侧组包然后刷写，因为需要的校验文件DA和authfile 都已经配置了。
  注意：生产线这块的方案可能需要你们或者OEM厂商定方案的，如果没啥特别定制要求，需要注意efuse 的烧录。
  
4.关于secureboot 的版本OTA部分需要找姚工讨论

5.secure boot范畴类的都只能是 2048或者3072 key。 其他security module的key要咨询对应的module，一般是RSA2048;

6. MTK86系列平台基于虚拟化op-tee使用手册 是介绍op-tee和平台相关匹配。

